from django.apps import AppConfig


class MainConfig(AppConfig):
   verbose_name = 'SitEee'
   name = 'main'